/*
BASE AnimeZoneGit
Youtube: AnimeZoneGit
*/

require("./labs");
require("./owner");
const fs = require('fs');
const util = require('util');
const axios = require('axios');
const { exec } = require("child_process");
const { tiktok, pinterest } = require("./Tools/exif");
const {
smsg, getGroupAdmins, formatp, h2k, tanggal, formatDate, getTime, isUrl, await, sleep, clockString, msToDate, sort, toNumber, enumGetKey, runtime, fetchJson, getBuffer, jsonformat, delay, format, logic, generateProfilePicture, parseMention, getRandom, pickRandom, reSize
} = require('./Tools/myfunction')

module.exports = async (AnimeZoneGit, m) => {
try {
const body = (
(m.mtype === 'conversation' && m.message.conversation) ||
(m.mtype === 'imageMessage' && m.message.imageMessage.caption) ||
(m.mtype === 'documentMessage' && m.message.documentMessage.caption) ||
(m.mtype === 'videoMessage' && m.message.videoMessage.caption) ||
(m.mtype === 'extendedTextMessage' && m.message.extendedTextMessage.text) ||
(m.mtype === 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ||
(m.mtype === 'templateButtonReplyMessage' && m.message.templateButtonReplyMessage.selectedId)
) ? (
(m.mtype === 'conversation' && m.message.conversation) ||
(m.mtype === 'imageMessage' && m.message.imageMessage.caption) ||
(m.mtype === 'documentMessage' && m.message.documentMessage.caption) ||
(m.mtype === 'videoMessage' && m.message.videoMessage.caption) ||
(m.mtype === 'extendedTextMessage' && m.message.extendedTextMessage.text) ||
(m.mtype === 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ||
(m.mtype === 'templateButtonReplyMessage' && m.message.templateButtonReplyMessage.selectedId)
) : '';

const budy = (typeof m.text === 'string') ? m.text : '';
const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
const isCmd = body.startsWith(prefix);
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
const args = body.trim().split(/ +/).slice(1)
const text = q = args.join(" ")
const sender = m.key.fromMe ? (AnimeZoneGit.user.id.split(':')[0]+'@s.whatsapp.net' || AnimeZoneGit.user.id) : (m.key.participant || m.key.remoteJid)
const botNumber = await AnimeZoneGit.decodeJid(AnimeZoneGit.user.id)
const senderNumber = sender.split('@')[0]
const isCreator = (m && m.sender && [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false;
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const quoted = m.quoted ? m.quoted : m
const from = m.key.remoteJid
const mime = (quoted.msg || quoted).mimetype || ''

async function loading () {
var AnimeZonegitLoad = [
"▶︎ •━━━━━━━━‌‌‌‌‌• 00:00",
" ꠰꠰︎ •၊၊၊|။•‌‌‌‌‌၊|၊|။|။‌‌‌‌‌၊|၊၊|။||||။‌‌‌‌‌• 00:10",
" ꠰꠰︎ •━|။|‌‌‌‌‌၊|၊|•|။‌‌‌‌‌၊|||။||||။‌‌‌‌‌• 00:50",
" ꠰꠰︎ •၊|━|‌‌‌‌‌၊|၊|။||‌‌‌‌‌၊|၊၊|•|၊||။‌‌‌‌‌• 01:35",
" ꠰꠰︎ •━━‌━၊||━၊|━|━|||‌‌‌‌‌• 01:58",
"Loading Selesai..."
]
let { key } = await AnimeZoneGit.sendMessage(m.chat, {text: 'Loading...'})

for (let i = 0; i < AnimeZonegitLoad.length; i++) {
await sleep(10)
await AnimeZoneGit.sendMessage(m.chat, {text: AnimeZonegitLoad[i], edit: key });
}
};

const { GoogleGenerativeAI, HarmBlockThreshold, HarmCategory } = require("@google/generative-ai");
const { GoogleAIFileManager } = require("@google/generative-ai/server");
const path = require("path");
  const Used_Apikey = "AIzaSyBYNYRhCeGMhBSIdzogTNXyYj4wpvGXLp4"
  const genAI = new GoogleGenerativeAI(Used_Apikey);
  const fileManager = new GoogleAIFileManager(Used_Apikey);
    if (m.isBaileys || m.fromMe || !m.text) return false;
    if (!budy.startsWith(".")) {
    try {
            const modell = genAI.getGenerativeModel({
  model: "gemini-2.0-flash",
  systemInstruction: sifat.AnimZone,
});
const promptt = m.text;
const resultp = await modell.generateContent(promptt);
const responseqo = await resultp.response;
const textl = responseqo.text();
m.reply(textl);
    } catch (err) {
        return err
}};

const floc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `Youtube: AnimeZoneGit`,jpegThumbnail: ''}}}
const fkontak = { key: {fromMe: false,participant: `6285729084817@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { 'contactMessage': { 'displayName': `${pushname}`, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;Vinzx,;;;\nFN:${pushname},\nitem1.TEL;waid=${sender.split('@')[0]}:${sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`, 'jpegThumbnail': { url: "https://files.catbox.moe/s0vxdt.jpg" }}}};
const reply = (teks) => {
AnimeZoneGit.sendMessage(from, { text: teks, contextInfo: {
            mentionedJid: [],
            groupMentions: [],
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363404418113256@newsletter',
               newsletterName: 'AnimeZoneProject',
                serverMessageId: -1
            },
            forwardingScore: 256,
externalAdReply: {
        showAdAttribution: true,
        title: `YouTube: AnimeZoneGit`,
        body: `Ai Interactive || Whatsapp`,
        thumbnailUrl: profileBot2,
        sourceUrl: "https://wa.me/6285729084817",
        mediaType: 1,
        renderLargerThumbnail: false
          }
        }}, { quoted: fkontak })};
        
if (budy === '.menu') {
await loading()
const Card = `Halo, Aku adalah ${bot_name}, Dan aku siap menjadi teman virtual yang belum terlalu ahli.

*Bot Information*
• Name: ${bot_name}
• Status: online

┏═[ *Download* ]
║≫.pin   [ pencarian  ]
║≫.tt     [ link video ]
╚━═━═━═━═━═𖥑
*FITUR AI :*
> Otomatis sudah menyala.

*© 2025 || By AnimeZoneGit*`;
AnimeZoneGit.sendMessage(m.chat, {
text: Card,
contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
title: "꧁Assistant AI꧂",
body: "Halo kak 👋",
thumbnailUrl: profileBot,
mediaType: 2,
mediaUrl: "https://www.youtube.com/@AnimeZoneGit",
sourceUrl: "https://www.youtube.com/@AnimeZoneGit"
}}}, {quoted: floc});
}

switch(command) {
case 'pin':
case 'pinterest': {
  if (!text) return reply(`Contoh: .pin BlueArchive`)
  try {
    let hasil = await pinterest(text)
    if (!hasil || hasil.length === 0) return m.reply('Gambar tidak ditemukan.')
    
    let randomImage = hasil[Math.floor(Math.random() * hasil.length)]

    await AnimeZoneGit.sendMessage(m.chat, {
      image: { url: randomImage },  
      caption: '*HASIL:* Pinterest\n> Airi : Sudah di temukan',
      footer: null,
      headerType: 1,
      viewOnce: false
    }, { quoted: fkontak })
  } catch (err) {
    console.error(err.message)
    m.reply('Terjadi kesalahan')
  }
}
break;
case 'tiktok':
case 'tt': {
if (args.length == 0) return m.reply(`Example: .tiktok link nya\n> Airi : Itu cara pakainya`)
let res = await tiktok(`${args[0]}`)
AnimeZoneGit.sendMessage(m.chat, { video: { url: res.nowm }, caption: res.title, fileName: `tiktok.mp4`, mimetype: 'video/mp4' }).then(() => {
AnimeZoneGit.sendMessage(m.chat, { audio: { url: res.audio }, fileName: `tiktok.mp3`, mimetype: 'audio/mp4' })
})
}
break;
default:
if (budy.startsWith('=>')) {
if (!isCreator) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return m.reply(bang)
}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))
}
}

if (budy.startsWith('>')) {
if (!isCreator) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

if (budy.startsWith('$')) {
if (!isCreator) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}
}

} catch (err) {
console.log(util.format(err))
}
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})
