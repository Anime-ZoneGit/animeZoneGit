require("./config");
const fs = require('fs');
const util = require('util');
const axios = require('axios');
const { exec } = require("child_process");
const { tiktok } = require("./Tools/exif");
const { youtube } = require("btch-downloader");

module.exports = async (AnimeZoneGit, m) => {
try {
const body = (
(m.mtype === 'conversation' && m.message.conversation) ||
(m.mtype === 'imageMessage' && m.message.imageMessage.caption) ||
(m.mtype === 'documentMessage' && m.message.documentMessage.caption) ||
(m.mtype === 'videoMessage' && m.message.videoMessage.caption) ||
(m.mtype === 'extendedTextMessage' && m.message.extendedTextMessage.text) ||
(m.mtype === 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ||
(m.mtype === 'templateButtonReplyMessage' && m.message.templateButtonReplyMessage.selectedId)
) ? (
(m.mtype === 'conversation' && m.message.conversation) ||
(m.mtype === 'imageMessage' && m.message.imageMessage.caption) ||
(m.mtype === 'documentMessage' && m.message.documentMessage.caption) ||
(m.mtype === 'videoMessage' && m.message.videoMessage.caption) ||
(m.mtype === 'extendedTextMessage' && m.message.extendedTextMessage.text) ||
(m.mtype === 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ||
(m.mtype === 'templateButtonReplyMessage' && m.message.templateButtonReplyMessage.selectedId)
) : '';

const budy = (typeof m.text === 'string') ? m.text : '';
const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
const isCmd = body.startsWith(prefix);
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
const args = body.trim().split(/ +/).slice(1)
const text = q = args.join(" ")
const sender = m.key.fromMe ? (AnimeZoneGit.user.id.split(':')[0]+'@s.whatsapp.net' || AnimeZoneGit.user.id) : (m.key.participant || m.key.remoteJid)
const botNumber = await AnimeZoneGit.decodeJid(AnimeZoneGit.user.id)
const senderNumber = sender.split('@')[0]
const isCreator = (m && m.sender && [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false;
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const autoaicuy = JSON.parse(fs.readFileSync("./autoai.json"));
const autoai = m.isGroup ? autoaicuy.includes(m.chat) : true

if (autoai) {
 if (m.text) {
    if (!m.isGroup) return
     if (isBot) return
     if (/^.*false|disable|(turn)?off|0/i.test(m.text)) {
if (!isAdmins && !isCreator) return reply('> Airi : Menatap dengan ceria')
let offf = autoaicuy.indexOf(from)
autoaicuy.splice(offf, 1)
fs.writeFileSync('./autoai.json', JSON.stringify(autoaicuy))
reply('> Airi : Airi tidak online dulu di group ya')
}
const { GoogleGenerativeAI, HarmBlockThreshold, HarmCategory } = require("@google/generative-ai");
const { GoogleAIFileManager } = require("@google/generative-ai/server");
const path = require("path");
  const Used_Apikey = "AIzaSyBYNYRhCeGMhBSIdzogTNXyYj4wpvGXLp4"
  const genAI = new GoogleGenerativeAI(Used_Apikey);
  const fileManager = new GoogleAIFileManager(Used_Apikey);
    if (m.isBaileys || m.fromMe || !m.text) return false;
    if (!budy.startsWith(".")) {
    try {
            const modell = genAI.getGenerativeModel({
  model: "gemini-2.0-flash",
  systemInstruction: sifat.AnimZone,
});
const promptt = m.text;
const resultp = await modell.generateContent(promptt);
const responseqo = await resultp.response;
const textl = responseqo.text();
m.reply(textl);
    } catch (err) {
        return err
}}}};

const floc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `Powered by AnimeZoneGit`,jpegThumbnail: ''}}}

if (budy === '.menu') {
const Card = `Halo, Aku adalah ${bot_name}, Dan aku siap menjadi teman virtual yang belum terlalu ahli.

*Bot Information*
• Name: ${bot_name}
• Status: online

┏═[ *Download* ]
║≫.tt     [ link video ]
║≫.play  [    title     ]
║≫.brat  [  No emoji ]
┏═[ *Nsfw* ]
║≫.waifu
║≫.neko
┏═[ *Anime* ]
║≫.anime
╚━═━═━═━═━═𖥑
*FITUR AI :*
> Otomatis sudah menyala.

*© 2025 || By AnimeZoneGit*`;
AnimeZoneGit.sendMessage(m.chat, {
text: Card,
contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
title: "꧁Assistant AI꧂",
body: "Halo kak 👋",
thumbnailUrl: profileBot,
mediaType: 1,
mediaUrl: "https://www.youtube.com/@AnimeZoneGit",
sourceUrl: "https://www.youtube.com/@AnimeZoneGit"
}}}, {quoted: floc});
}

switch(command) {
case 'autoai': {
if (!m.isGroup) return m.reply("> Airi : khusus di grup")
if (!isAdmins && !isCreator) return m.reply('> Airi : Khusus Admin dan owner kak')
if (args[0] === "nyalakan") {
autoaicuy.push(from)
fs.writeFileSync('./autoai.json', JSON.stringify(autoaicuy))
m.reply('> Airi : Online di group lagi')
} else m.reply("> Airi : Lelah")
}
break;
case 'runtime': {
  m.reply(`Airi runtime: ${runtime(process.uptime())}`)
}
break;
case "pin": case "pinterest": {
if (!text) return m.reply(example("anime dark"))
await AnimeZoneGit.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let pin = await pinterest2(text)
if (pin.length > 10) await pin.splice(0, 11)
const txts = text
let araara = new Array()
let urutan = 0
for (let a of pin) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.images_url}`}}, { upload: AnimeZoneGit.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"https://youtube.com/@AnimeZoneGit\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `\nBerikut adalah foto hasil pencarian dari *pinterest*\n\n> Airi - Assistant`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await AnimeZoneGit.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
await AnimeZoneGit.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break;
case 'neko' :
await loading()
waifudd = await axios.get(`https://waifu.pics/api/nsfw/neko`)
AnimeZoneGit.sendMessage(from, {image: {url:waifudd.data.url},caption:`> Airi : Jangan lupa istighfar`},{ quoted:m }).catch(err => {
 return('> Airi : Ada error sepertinya')
})
break;
case 'waifu' :
await loading()
waifudd = await axios.get(`https://waifu.pics/api/nsfw/waifu`) 
AnimeZoneGit.sendMessage(from, {image: {url:waifudd.data.url},caption:`> Airi : Jangan lupa istighfar`}, { quoted:m }).catch(err => {
 return('> Airi : Ada error sepertinya')
})
break;
case 'anime' :
await loading()
waifudd = await axios.get(`https://waifu.pics/api/sfw/waifu`) 
AnimeZoneGit.sendMessage(from, {image: {url:waifudd.data.url},caption:`> Airi : Jangan lupa istighfar`}, { quoted:m }).catch(err => {
 return('> Airi : Ada error sepertinya')
})
break;
case 'tiktok':
case 'tt': {
if (args.length == 0) return m.reply(`Example: .tiktok link nya`)
let res = await tiktok(`${args[0]}`)
AnimeZoneGit.sendMessage(m.chat, { video: { url: res.nowm }, caption: res.title, fileName: `tiktok.mp4`, mimetype: 'video/mp4' }).then(() => {
AnimeZoneGit.sendMessage(m.chat, { audio: { url: res.audio }, fileName: `tiktok.mp3`, mimetype: 'audio/mp4' })
})
}
break;
case 'play':  case 'song': {
if (!text) return m.reply(`Example : ${prefix + command} anime whatsapp status`)
await m.reply('tunggu sebentar');
let yts = require("youtube-yts")
        let look = await yts(text);
        let convert = look.videos[0];       
const pl = await youtube(convert.url)
await AnimeZoneGit.sendMessage(m.chat,{
    audio: { url: pl.mp3  },
    fileName: convert.title + '.mp3',
    mimetype: 'audio/mpeg',
    contextInfo:{
        externalAdReply:{
            title:convert.title,
            body: botname,
            thumbnailUrl: convert.image,
            sourceUrl: pl.mp3,
            mediaType:1,
            mediaUrl:convert.url,
        }

    },
},{quoted:m})
m.reply('Maaf kalau terlambat\n> Airi - Assistant')
}
break;
case 'brat': {
  if (!text) return reply(`Penggunaan : ${prefix + command} <teks>`);
  try {
    const { createCanvas, registerFont } = require('canvas');
    const Jimp = require('jimp');
    
    registerFont('./Tools/arialnarrow.ttf', { family: 'ArialNarrow' });
    const canvas = createCanvas(512, 512);
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    const findOptimalFontSize = (text, maxWidth, maxHeight) => {
      let fontSize = 280;
      ctx.font = `bold ${fontSize}px ArialNarrow`; 
      const words = text.split(' ');
      let lines = [];

      while (fontSize > 0) {
        lines = [];
        let currentLine = [];
        let currentWidth = 0;
        ctx.font = `bold ${fontSize}px ArialNarrow`;
        
        for (const word of words) {
          const wordWidth = ctx.measureText(word + ' ').width;
          if (currentWidth + wordWidth <= maxWidth) {
            currentLine.push(word);
            currentWidth += wordWidth;
          } else {
            if (currentLine.length > 0) {
              lines.push(currentLine);
            }
            currentLine = [word];
            currentWidth = wordWidth;
          }
        }
        if (currentLine.length > 0) {
          lines.push(currentLine);
        }

        const totalHeight = lines.length * (fontSize + 10);
        if (totalHeight <= maxHeight) {
          break;
        }
        fontSize -= 2;
      }
      return { fontSize, lines };
    };

    const padding = 48;
    const maxWidth = canvas.width - (padding * 2);
    const maxHeight = canvas.height - (padding * 2);
    const { fontSize, lines } = findOptimalFontSize(q, maxWidth, maxHeight);

    ctx.fillStyle = '#000000';
    ctx.font = `bold ${fontSize}px ArialNarrow`; 
    
    const lineHeight = fontSize + 10;
    const totalHeight = lines.length * lineHeight;
    const startY = (canvas.height - totalHeight) / 2 + fontSize / 2;

    lines.forEach((line, i) => {
      if (i === lines.length - 1 && line.length === 1) {
        ctx.textAlign = 'center';
        ctx.fillText(line.join(' '), canvas.width / 2, startY + (i * lineHeight));
      } else {
         
        const totalSpacing = maxWidth - line.reduce((acc, word) => acc + ctx.measureText(word).width, 0);
        const spaceBetween = line.length > 1 ? totalSpacing / (line.length - 1) : 0;
        
        let currentX = padding;
        line.forEach((word, j) => {
          ctx.fillText(word, currentX, startY + (i * lineHeight));
          currentX += ctx.measureText(word).width + spaceBetween;
        });
      }
    });
const buffer = canvas.toBuffer();
let image = await Jimp.read(buffer);

image.blur(2);
let blurredBuffer = await image.getBufferAsync(Jimp.MIME_PNG);
    
    await AnimeZoneGit.imgToSticker(m.chat, blurredBuffer, m, { packname: "YouTube :", author: "AnimeZoneGit" })

  } catch (e) {
    console.log(e);
    await reply(`Terjadi kesalahan saat membuat stiker`);
  }
}
break;
default:
if (budy.startsWith('=>')) {
if (!isCreator) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return m.reply(bang)
}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))
}
}

if (budy.startsWith('>')) {
if (!isCreator) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

if (budy.startsWith('$')) {
if (!isCreator) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}
}

} catch (err) {
console.log(util.format(err))
}
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})
