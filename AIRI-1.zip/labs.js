/*
BASE AnimeZoneGit
Youtube: AnimeZoneGit
*/

global.bot_name = '-'
global.profileBot = '-'
global.profileBot2 = '-'
// Ganti Dengan logic/promt sesuai dengan cara kalian
global.sifat = {
  AnimZone: '-',
};

global.APIs = {
	ai_api: 'https://animezonegit.private.com/api',
}
global.APIKeys = {
	'https://animezonegit.private.com/api': 'AnimZone-22free',
}
/* Api di lindungi */

let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})