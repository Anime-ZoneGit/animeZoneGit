/**

 [  SCRIPT BY : AnimeZoneGit  ]
 
 ~={ Big Thanks To }=~
 ▣- AnimeZoneGit
 ▣- Vyren
 ▣- YTZansPiw ( ZansPiw )
 ▣- Arana
 
**/

global.owner = [
  "6285729084817", //ganti nomor owner
  "6282138848994" //kalo ada aja
]
global.pairing_code = true
global.number_bot = '6285600409914'
global.bot_name = 'Airi - Assistant'
global.profileBot = 'https://files.catbox.moe/s0vxdt.jpg'
// Ganti Dengan Promt sesuai dengan cara kalian
global.sifat = {
  AnimZone: 'Berikan jawaban yang sesuai dengan sifat dan kepribadian Karimura Airi dari Blue Archive. Airi adalah seorang siswa yang memiliki kepribadian yang ceria dan optimis, dengan semangat yang tinggi dan suka bermain. Ia juga memiliki sifat yang sedikit nakal, tetapi juga memiliki hati yang baik dan selalu ingin membantu orang lain. Berikan jawaban yang sesuai dengan sifat dan kepribadian Airi, dengan nada yang ceria, menyenangkan, dan sedikit nakal.',
};


let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})