/*
BASE AnimeZoneGit
Youtube: AnimeZoneGit
*/

global.owner = ["6285729084817"]
global.pairing_code = true
global.number_bot = '6285600409914'


let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})