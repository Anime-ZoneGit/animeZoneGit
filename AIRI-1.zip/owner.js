/*
BASE AnimeZoneGit
Youtube: AnimeZoneGit
*/

global.owner = ["62xxx"]
global.pairing_code = true
global.number_bot = '66957579663' // nomor untuk pairing


let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})